from views.apps.model import api

def test_passing() -> None:
    pass