""" Model specification """
__all__ = ["api"]
from . import api
