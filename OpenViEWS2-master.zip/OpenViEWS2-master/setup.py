""" Setup file fore views project """
import os
from setuptools import setup

def main():
    """ Do the setup """
    setup(name='views',
          version='0.0.1',
          author="ViEWS Team",
          install_requires=[])

if __name__ == "__main__":
    main()
