# Welcome

Welcome to the ViEWS prediction competition.

# Getting started

See the README.md in the root of this repository for installing and starting the jupyter notebook server.
Then navigate to this directory in the jupyter notebook browser window and open example_notebook.ipynb

Good luck!